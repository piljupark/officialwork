$(function () {
    $('#fullpage').fullpage({
        //options here
        autoScrolling: true,
        scrollHorizontally: true
    });
    
    $('.main-logo').on('click',function(){
        $.fn.fullpage.moveTo(1);
    });

    //methods
    
    
    $("#fullpage > .section3 > .showroom-place > .showroom-info > .seongsu").click(function(){
        $("#fullpage > .section3 > .showroom-place > .showroom-info > .seongsu").css("background","#292929");
        $("#fullpage > .section3 > .showroom-place > .showroom-info > .seongsu > .next-arrow").css("display","block");
        $("#fullpage > .section3 > .showroom-place > .showroom-info > .seongsu > .button-wrap").css("display","block");
        
        
        $("#fullpage > .section3 > .showroom-place > .showroom-info > .seongsu > .txt-eng-bold").css("color","#fff");
    });
    
    
});
