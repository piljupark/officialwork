$(function () {
    
  $('#fullpage').fullpage({
            //options here
            autoScrolling: true,
            scrollHorizontally: true,
        });
    //methods
});



